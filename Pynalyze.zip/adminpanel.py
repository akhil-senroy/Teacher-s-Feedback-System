# Pran P. Saha
import os
from tkinter import *
from tkinter import messagebox
from tkinter import ttk


import pymysql as pm


# from tg1 import tg1


class AdminPanel(ttk.Frame):
    def __init__(self, parent, controller, host):
        from dbase import DbConnect
        ttk.Frame.__init__(self, parent)
        menu_bar = Menu(controller)
        controller['menu'] = menu_bar
        menu_file = Menu(menu_bar)
        menu_edit = Menu(menu_bar)
        menu_setting = Menu(menu_bar)
        menu_bar.add_cascade(menu=menu_file, label='File')
        menu_bar.add_cascade(menu=menu_edit, label='Edit')
        menu_setting.add_cascade(menu=menu_edit, label='setting')
        self.percent = DoubleVar()
        self.fb = StringVar()
        self.ip = host
        self.db = DbConnect(self.ip)

        n = ttk.Notebook(self)
        # general = ttk.Frame(n)  # first page, which would get widgets gridded into it
        tools = ttk.Frame(n)  # second page
        stats = ttk.Frame(n)  # graph page

        graph = ttk.Combobox(stats)
        graph['values'] = ('', 'All teachers')
        graph.current(0)
        graph.grid(row=0, column=0, padx=10, pady=10)
        # ttk.Button(stats, text='Generate graph', command=lambda: tg1(host)).grid(row=0, column=1, padx=10, pady=10)

        mail = ttk.Combobox(stats)
        db = DbConnect(self.ip)
        db.cu.execute('select t_name from mt_teacher')
        row = db.cu.fetchall()
        # print(row)
        mail['values'] = row
        mail.grid(row=1, column=0)
        ttk.Button(stats, text="Send Mail", command=lambda: messagebox.showinfo('Pynalyze', 'Message sent successfully')
                   ).grid(row=1, column=1)

        # sel = ttk.LabelFrame(general, text='Selection')
        # sel.grid(row=0, column=0, padx=10, pady=10)

        # ttk.Label(sel, text='Select Department code').grid(row=0, column=0, padx=10, pady=10, sticky=W)
        # self.dept = ttk.Combobox(sel)
        # self.dept.grid(row=0, column=1, sticky=W)
        # self.db.cu.execute('select distinct s_dept from student')
        # self.dept['values'] = self.db.cu.fetchall()

        # ttk.Entry(sel, textvariable=self.percent).grid(row=1, column=1, sticky=W)
        # ttk.Label(sel, text='Minimum Percentage : ').grid(row=1, column=0, padx=10, pady=10, sticky=W)

        # ttk.Label(sel, text='Select Semester').grid(row=2, column=0, padx=10, pady=10, sticky=W)
        # self.sem = ttk.Combobox(sel)
        # self.sem.grid(row=2, column=1, sticky=W)
        self.db.cu.execute('select distinct s_sem from student')
        # self.sem['values'] = self.db.cu.fetchall()

        # ttk.Label(sel, text='Select Division').grid(row=3, column=0, padx=10, pady=10, sticky=W)
        # self.div = ttk.Combobox(sel)
        # self.div.grid(row=3, column=1, sticky=W)
        # self.db.cu.execute('select distinct s_div from student')
        # self.div['values'] = self.db.cu.fetchall()

        # ttk.Label(sel, text='Type of Feedback').grid(row=4, column=0, padx=10, pady=10, sticky=W)
        # sf = ttk.Frame(sel, borderwidth=2, relief=GROOVE)
        # sf.grid(row=4, column=1, sticky=E)
        # ttk.Radiobutton(sf, variable=self.fb, text='Standard', value='0').grid(row=0, column=0)
        # ttk.Radiobutton(sf, variable=self.fb, text='Behavioral', value='1').grid(row=0, column=1)
        # ttk.Button(sel, text='Start', command=lambda: self.update_all()).grid(row=5, column=2)
        self.db.db.close()
        # n.add(general, text='General')
        n.add(tools, text='Tools')
        n.add(stats, text='Stats')
        n.grid()

        ttk.Button(tools, text="Add User").grid(row=0, column=0, padx=10, pady=10, sticky=W)
        ttk.Button(tools, text="Generate Table", command=lambda: self.create_entries())\
            .grid(row=1, column=0, padx=10, pady=10, sticky=W)
        ttk.Button(tools, text="Report", command=lambda: self.show_report()).\
            grid(row=2, column=0, padx=10, pady=10, sticky=W)

        for child in self.winfo_children():
            child.grid_configure(padx=5, pady=5)

    def update_all(self):
        from dbase import DbConnect
        db = DbConnect(self.ip)
        db.cu.execute('update con set i='+str(self.fb.get())+' where p=1')
        db.db.commit()
        messagebox.showinfo("Pynalyze", "feedback session  has started")

    def create_entries(self):
        from dbase import DbConnect
        import datetime
        db = DbConnect(self.ip)
        time_input = datetime.date.today().strftime("%B %Y")
        # stmt = 'select t_id from mt_teacher'
        # db.cu.execute(stmt)
        db.cu.execute('select t_id,t_sub,t_div from teacher')
        res = db.cu.fetchall()
        stmt = 'select t_id from feedback where time="'+time_input+'"'
        db.cu.execute(stmt)
        check = db.cu.fetchall()
        stmt = 'select count(q_id) from mt_question'
        db.cu.execute(stmt)
        c = db.cu.fetchone()
        db.cu.execute('select t_id, t_sub, batch from practical')
        prac = db.cu.fetchall()
        res = res + prac
        try:
            if len(check) != 0:
                messagebox.showerror("Pynalyze", "Data table already exists !")
            else:
                for i in range(len(res)):
                    for j in range(c[0]):
                        # stmt = ("INSERT INTO feedback "
                        #         "(t_id, q_id, time) "
                        #         "values (%s, %s, %s);")
                        # data = (res[i], j+1, time_input)
                        stmt = ("INSERT INTO feedback "
                                "(t_id, q_id, time, t_sub, t_div) "
                                "value (%s, %s, %s, %s, %s);")
                        data = (res[i][0], j+1, time_input, res[i][1], res[i][2])
                        db.cu.execute(stmt, data)
                messagebox.showinfo("Pynalyze", "Table Created Successfully")
                db.db.commit()
        except pm.err:
            db.db.rollback()

    def show_report(self):
        print("starting")
        from dbase import DbConnect
        rpt_top = Toplevel(self)
        rpt_top.lift()

        ttk.Label(rpt_top, text="Select Department").grid(row=0, column=0, padx=10, pady=10, ipadx=5, ipady=5)
        dept_list = ttk.Combobox(rpt_top)
        dept_list.grid(row=0, column=1, padx=10, pady=10, ipadx=5, ipady=5)

        db = DbConnect(self.ip)
        db.cu.execute('SELECT DISTINCT(`dept`) FROM `teacher`')
        row = db.cu.fetchall()
        dept_list['values'] = row
        dept = dept_list.get()
        # row = db.cu.fetchall()
        ttk.Button(rpt_top, text="Generate", command=lambda: self.make_report(dept_list.get())). \
            grid(row=1, column=1, padx=10, pady=10, ipadx=5, ipady=5)
        # lambda: self.make_report(dept_list.get())). \

    def make_report(self, dept):
        print("initializing")
        import datetime
        from dbase import DbConnect
        db = DbConnect(self.ip)
        dept = str(dept)
        db.cu.execute("SELECT t_id, t_sub, t_div from teacher where dept=%s", dept)
        t_res = db.cu.fetchall()
        time_input = datetime.date.today().strftime("%B %Y")
        db.cu.execute("select distinct(time) from feedback")
        time_in = db.cu.fetchone()
        time_in = time_in[0]

        for detail in t_res:
            tid = detail[0]
            print(tid)
            # ---------------------------COLLECTING VARIABLES------------------------------
            db.cu.execute("Select t_name from mt_teacher where t_id={}".format(tid))
            r1 = db.cu.fetchone()
            t_name = r1[0]

            db.cu.execute("Select dept from teacher where t_id={}".format(tid))
            r1 = db.cu.fetchone()
            t_dept = r1[0]

            t_sub = detail[1]
            t_div = detail[2]
            # print(t_sub)
            # print t_sub
            db.cu.execute("Select AVG(avg) from feedback where t_id=(%s) and time=(%s) and t_sub=%s and t_div=%s",
                          (tid, time_in, t_sub, t_div))
            r1 = db.cu.fetchone()
            final_rating = r1[0]
            final_rating = round(final_rating, 3)
            # ---------------------------WRITING IN FILE---------------------------------------------
            filepath = t_dept + "_" + time_in
            if not os.path.exists(filepath):
                os.makedirs(filepath)
            filename = t_name + "_" + t_sub + "_" + t_div
            f = open("{}/{}.txt".format(filepath, filename), "w+")
            f.write("==>Teacher name \t: {}\n".format(t_name))
            f.write("==>Subject \t\t: {}\n==>Department \t\t: {}\n".format(t_sub, t_dept))
            f.write("==>Division \t\t: {}\n".format(t_div))
            f.write("\n\t\t-----------------SCORE-----------------\n")
            db.cu.execute("Select avg from feedback where t_id=(%s) and time=(%s) and t_sub=(%s) and t_div=%s",
                          (tid, time_in, t_sub, t_div))
            avg = db.cu.fetchall()
            num_rows = db.cu.rowcount
            db.cu.execute("Select q_tag from mt_question")
            q_text = db.cu.fetchall()
            final_pct = (final_rating / 5) * 100
            for x in range(0, num_rows):
                pct = (avg[x][0] / 5) * 100
                # f.write("%s)" % (x+1)+"%s" % str(q_text[0])+" - %s/5" % str(avg[0])+"\n\n")
                f.write("{}) {} %\t||{}\n\n".format(x + 1, round(pct, 2), q_text[x][0]))
            f.write("\n\t\t--------------TOTAL SCORE--------------\n")
            f.write("\t\t\t-----------------------\n\t\t\t\t{} %\n\t\t\t-----------------------\n\n".
                    format(round(final_pct, 3)))
            f.write("_________________\n")
            f.write("   SIGNATURE")

            # self.make_graph(tid)
            db.cu.execute("select review from teacher_review where t_id=%s and time= %s", (tid, time_in))
            rev = db.cu.fetchall()
            f.write("\n\n\n\n\n\n\n\n\n\n\n\n\t--------Reviews--------\n\n")
            for i in rev:
                f.write("\n{} \n".format(i[0]))
            # self.make_graph(tid, filepath)
            f.close()
        messagebox.showinfo("Pynalyze", "Report Generated")
'''
    def make_graph(self, x, path):

        from dbase import DbConnect
        db = DbConnect(self.ip)
        r = []
        stmt = """select avg from feedback where t_id=%s and q_id=%s"""
        for i in range(12):
            db.cu.execute(stmt, (x, i + 1))
            r.append(db.cu.fetchone()[0])
        db.cu.execute("Select t_name from mt_teacher where t_id=(%s)", x)
        name = db.cu.fetchone()[0]

        plt.rcdefaults()

        # from matplotlib.ticker import FormatStrFormatter
        plt.tick_params(axis='both', which='major', labelsize=8)
        plt.tick_params(axis='both', which='minor', labelsize=7)

        objects = ('EXPLANATION', 'OPPORTUNITY', 'STIMULATION', 'SYLLABUS COMP.', 'TIME USAGE', 'PAPER CORRECTION',
                   'COMM.', 'CLASS CONTROL', 'ATTITUDE', 'VICTIMIZATION', 'FAVOURITISM', 'PUNCTUAL')
        y_pos = np.arange(len(objects))

        performance = []
        for i in range(12):
            performance.append(r[i])
        print(performance)
        bar = plt.bar(y_pos, performance, width=0.75, color='y', align='center', alpha=1.0)

        bar[0].set_color('orange')
        bar[1].set_color('blue')
        bar[2].set_color('green')
        bar[3].set_color('purple')
        bar[4].set_color('red')
        bar[5].set_color('brown')
        bar[6].set_color('pink')
        bar[7].set_color('grey')
        bar[8].set_color('olive')
        bar[9].set_color('black')
        bar[10].set_color('yellow')
        bar[11].set_color('cyan')

        plt.xticks(y_pos, objects)
        plt.ylabel('Ratings')
        plt.title(name)
        manager = plt.get_current_fig_manager()
        manager.window.showMaximized()
        # plt.show()
        plt.savefig(path + '/' + name + '.pdf', bbox_inches='tight')
        plt.savefig(path + '/' + name + '.png', bbox_inches='tight')
        plt.close()
'''
